function counter(){
    let count = 1
}