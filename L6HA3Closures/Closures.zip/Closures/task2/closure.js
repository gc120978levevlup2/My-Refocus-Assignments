function counter(){
    let count = 1
    function add(){
        count++
        return count
    }
}