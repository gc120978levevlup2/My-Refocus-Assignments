let a = new (require("./Developer.js"))("Garry M. Cacho", 300, "Front-end web development");
a.printIntro();
a.printSalary();
a.printSpecialty();
a.printEmployer();