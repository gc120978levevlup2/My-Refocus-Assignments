let firstName = 'Ferdinand'
let  lastName = 'Marcos'
const msg =  `Hello, ${firstName} ${lastName}! How can we help you today?`
console.log(msg)