const vaxdoses = () => {
    return [
    {
        numeral: null,
        name   : '---- Please Select a Vaccionation Dose Brand ----' 
    },
    {
        numeral: 'Vax 1',
        name   : 'Pfizer-BioNTech'  
    },
    {
        numeral: 'Vax 2',
        name   : 'AstraZeneca'  
    },
    {
        numeral: 'Vax 3',
        name   : 'Coronavac'  
    },
    {
        numeral: 'Vax 4',
        name   : 'Sputnik V'  
    },
    {
        numeral: 'Vax 5',
        name   : 'Janssen'  
    },
    {
        numeral: 'Vax 6',
        name   : 'Covaxin'  
    },
    {
        numeral: 'Vax 7',
        name   : 'Moderna'  
    },
    {
        numeral: 'Vax 8',
        name   : 'Sinopharm'  
    },
    {
        numeral: 'Vax 9',
        name   : 'Covovax'   
    }
]};

export default vaxdoses;