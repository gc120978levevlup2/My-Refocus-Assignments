// Corrected code below bug free
const flowers = ["rose" , "star gazer" , "tulips" , "sun flower"];

for(i = 0;i<flowers.length;i++){
    console.log(flowers[i].length)
}