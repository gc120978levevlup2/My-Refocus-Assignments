# Prerequisites to Run Properly
    It is advisable to use Live Server to serve the code starting in the index.html file.

# About
    This is a simple example of a website CV that describes myself and my skills to potential employers.