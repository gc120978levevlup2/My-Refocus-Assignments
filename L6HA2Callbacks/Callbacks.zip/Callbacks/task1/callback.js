function discount(percentage=0, aount = 0){
    return (amount - (amount * (percentage / 100)))
}